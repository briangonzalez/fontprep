// Namespace the entire FontPrep frontend.
// -------------------------------------------
var FP                    = FP || {};
FP.Routes                 = {};
FP.Views                  = {};
FP.Views.App              = {};
FP.Views.Viewer           = {};

window.pageHasLoaded  = false;
